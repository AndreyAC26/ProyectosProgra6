﻿using Entidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace mvcInterfazUsuario.Controllers
{
    public class CountryRegionController : Controller
    {        
        //*********ENTIDADES*********//
        public ActionResult listarCountryRegions_ENT()
        {
            List<CountryRegion> lobjRespuesta = new List<CountryRegion>();
            try
            {
                using (srvCountryRegion.IsrvCountryRegionClient srvWCF_CR = new srvCountryRegion.IsrvCountryRegionClient())
                {
                    lobjRespuesta = srvWCF_CR.recCountryRegion_ENT();
                }
            }
            catch (Exception lEx)
            {

                throw lEx;
            }
            return View(lobjRespuesta);
        }

        public ActionResult agregarCountryRegions_ENT()
        {
            return View();
        }

        public ActionResult modificarCountryRegions_ENT(string pId)
        {
            CountryRegion lobjRespuesta = new CountryRegion();
            try
            {
                using (srvCountryRegion.IsrvCountryRegionClient srvWCF_CR = new srvCountryRegion.IsrvCountryRegionClient())
                {
                    lobjRespuesta = srvWCF_CR.recCountryRegionXId_ENT(pId);
                }
            }
            catch (Exception lEx)
            {

                throw lEx;
            }
            return View(lobjRespuesta);
        }

        public ActionResult eliminarCountryRegions_ENT(string pId)
        {
            CountryRegion lobjRespuesta = new CountryRegion();
            try
            {
                using (srvCountryRegion.IsrvCountryRegionClient srvWCF_CR = new srvCountryRegion.IsrvCountryRegionClient())
                {
                    lobjRespuesta = srvWCF_CR.recCountryRegionXId_ENT(pId);
                }
            }
            catch (Exception lEx)
            {

                throw lEx;
            }
            return View(lobjRespuesta);
        }

        public ActionResult detalleCountryRegions_ENT(string pId)
        {
            CountryRegion lobjRespuesta = new CountryRegion();
            try
            {
                using (srvCountryRegion.IsrvCountryRegionClient srvWCF_CR = new srvCountryRegion.IsrvCountryRegionClient())
                {
                    lobjRespuesta = srvWCF_CR.recCountryRegionXId_ENT(pId);
                }
            }
            catch (Exception lEx)
            {

                throw lEx;
            }
            return View(lobjRespuesta);
        }

    }
}