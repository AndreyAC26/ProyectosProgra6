﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace mvcInterfazUsuario.Models
{
    public class modeloLogin
    {
        public string usuario { get; set; }
        public string contrasena { get; set; }
    }
}